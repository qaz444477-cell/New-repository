package app.mawaqeet;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

/** Methods the page can call as window.AndroidBridge.* */
public class Bridge {
    private final Context ctx;

    public Bridge(Context ctx) { this.ctx = ctx; }

    /** Receives {silent, silentMin, events:[{id, at, kind, key, title, body}]} and schedules the alarms. */
    @JavascriptInterface
    public void sync(String json) {
        Scheduler.save(ctx, json);
        Scheduler.schedule(ctx, json);
    }

    @JavascriptInterface
    public boolean hasDndAccess() {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.isNotificationPolicyAccessGranted();
    }

    @JavascriptInterface
    public void openDndSettings() {
        Intent i = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    @JavascriptInterface
    public void test() {
        AlarmReceiver.notifyNow(ctx, "adhan", "تجربة المنبّه", "هكذا سيصلك تنبيه الأذان");
    }
}

package app.mawaqeet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Re-creates the alarms after a reboot, an app update or a clock/timezone change. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Scheduler.scheduleFromSaved(c);
    }
}

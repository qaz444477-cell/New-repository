package app.mawaqeet;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;

public class AlarmReceiver extends BroadcastReceiver {
    static final String ACTION_RESTORE = "app.mawaqeet.RESTORE";
    static final String CH_ADHAN = "adhan";
    static final String CH_LEAD = "lead";
    static final String KEY_PREV_FILTER = "prevFilter";
    static final String KEY_IN_SILENT = "inSilent";

    @Override
    public void onReceive(Context c, Intent i) {
        if (ACTION_RESTORE.equals(i.getAction())) {
            restoreSound(c);
            return;
        }
        String kind = i.getStringExtra("kind");
        notifyNow(c, kind == null ? "adhan" : kind, i.getStringExtra("title"), i.getStringExtra("body"));

        if (i.getBooleanExtra("silent", false)) {
            muteForPrayer(c, i.getIntExtra("silentMin", 20));
        }
    }

    static void ensureChannels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CH_ADHAN) == null) {
            NotificationChannel ch = new NotificationChannel(CH_ADHAN, "أذان الصلاة", NotificationManager.IMPORTANCE_HIGH);
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            ch.setSound(sound, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_LEAD) == null) {
            NotificationChannel ch = new NotificationChannel(CH_LEAD, "تنبيه قبل الأذان", NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
        }
    }

    static void notifyNow(Context c, String kind, String title, String body) {
        ensureChannels(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(c, "adhan".equals(kind) ? CH_ADHAN : CH_LEAD)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(open)
                .setAutoCancel(true);
        nm.notify((int) (System.currentTimeMillis() % 100000), b.build());
    }

    static void muteForPrayer(Context c, int minutes) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) return;

        android.content.SharedPreferences p = Scheduler.prefs(c);
        if (!p.getBoolean(KEY_IN_SILENT, false)) {
            p.edit().putInt(KEY_PREV_FILTER, nm.getCurrentInterruptionFilter())
                    .putBoolean(KEY_IN_SILENT, true).apply();
        }
        /* alarms only: calls and notifications are muted, alarms still ring */
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);

        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent r = new Intent(c, AlarmReceiver.class).setAction(ACTION_RESTORE);
        PendingIntent pi = Scheduler.pending(c, Scheduler.RESTORE_CODE, r);
        Scheduler.setExact(c, am, System.currentTimeMillis() + minutes * 60_000L, pi);
    }

    static void restoreSound(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        android.content.SharedPreferences p = Scheduler.prefs(c);
        if (p.getBoolean(KEY_IN_SILENT, false) && nm.isNotificationPolicyAccessGranted()) {
            int prev = p.getInt(KEY_PREV_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL);
            if (prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN) prev = NotificationManager.INTERRUPTION_FILTER_ALL;
            nm.setInterruptionFilter(prev);
        }
        p.edit().putBoolean(KEY_IN_SILENT, false).apply();
    }
}

package app.mawaqeet;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public class Scheduler {
    static final String PREFS = "mawaqeet";
    static final String KEY_PAYLOAD = "payload";
    static final String KEY_COUNT = "count";
    static final int RESTORE_CODE = 99999;
    static final int MAX_ALARMS = 400;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void save(Context c, String json) {
        prefs(c).edit().putString(KEY_PAYLOAD, json).apply();
    }

    static PendingIntent pending(Context c, int code, Intent i) {
        return PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void scheduleFromSaved(Context c) {
        String json = prefs(c).getString(KEY_PAYLOAD, null);
        if (json != null) schedule(c, json);
    }

    static void schedule(Context c, String json) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        int old = prefs(c).getInt(KEY_COUNT, 0);
        for (int i = 0; i < old; i++) {
            am.cancel(pending(c, i, new Intent(c, AlarmReceiver.class)));
        }

        int n = 0;
        try {
            JSONObject root = new JSONObject(json);
            boolean silent = root.optBoolean("silent", false);
            int silentMin = root.optInt("silentMin", 20);
            JSONArray ev = root.getJSONArray("events");
            long now = System.currentTimeMillis();
            for (int i = 0; i < ev.length() && n < MAX_ALARMS; i++) {
                JSONObject e = ev.getJSONObject(i);
                long at = e.getLong("at");
                if (at <= now) continue;
                Intent it = new Intent(c, AlarmReceiver.class);
                it.setAction("app.mawaqeet.ALARM");
                it.putExtra("kind", e.optString("kind", "adhan"));
                it.putExtra("title", e.optString("title", ""));
                it.putExtra("body", e.optString("body", ""));
                it.putExtra("silent", silent && "adhan".equals(e.optString("kind")));
                it.putExtra("silentMin", silentMin);
                PendingIntent pi = pending(c, n, it);
                setExact(c, am, at, pi);
                n++;
            }
        } catch (Exception ignored) { }
        prefs(c).edit().putInt(KEY_COUNT, n).apply();
    }

    /** setAlarmClock is exact, survives Doze and needs no special permission. */
    static void setExact(Context c, AlarmManager am, long at, PendingIntent pi) {
        Intent show = new Intent(c, MainActivity.class);
        PendingIntent showPi = PendingIntent.getActivity(c, 0, show, PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showPi), pi);
    }
}

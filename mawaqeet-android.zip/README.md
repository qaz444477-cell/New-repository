# مواقيت الصلاة - مشروع أندرويد

بناء ملف APK:
- من GitHub: ارفع هذا المجلد كمستودع، ثم Actions > Build APK > Run workflow، ونزّل mawaqeet-apk.
- من Android Studio: File > Open على هذا المجلد، ثم Build > Build APK(s).
- من الطرفية (JDK 17 وAndroid SDK): gradle assembleDebug
